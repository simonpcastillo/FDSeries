#' Abundance data through different time bins
#'
#' Add data description

#' @docType data
#'
#' @usage data(data0)
#'
#' @format A dataframe with time-bins rows and life-mode columns, Dataframe values are estimated abundances.
#'
#' @keywords datasets
#'
#' #add source and reference#
#'
#'
#' @examples
#' data(data0)
#' time.bins <- nrow(data0)
#' lifemodeRichness <- ncol(data0)

"data0"
