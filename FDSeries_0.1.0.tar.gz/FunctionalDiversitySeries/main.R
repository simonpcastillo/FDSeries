require(FunctionalDiversitySeries)
# The package is under development, anyway you can call for ? to get some info about each function

#The package already includes a dataset called data0
View(data0)

#1 function FD_df
# it reshape de original df extending ecocodes and creates data1' IMPORTANT.
data1<- FD_df(data0, subcat = c(6,6,6,3,2,3,3,4))

#The function returns a dataframe called data1
View(head(data1)) # first five entries


# Function 2 FD_rao
# Computes Simpson, Rao and FRedundancy and returns them by time bin
RaoSummary <- FD_Rao(df=data1)
#and returns a dataframe called RaoSummary with the estimates
View(RaoSummary)

#Function 3 FD_metrics
# variation of Villeger. Calculates FSpe, FRic, etc..
FDSummary <- FD_metrics(df = data1)
# it reteurns several objects into the environment and to the console. The main one is FDSummary, the others are for graphical purposes.
View(FDSummary)



############
# Plots


# Function 4 FD_plotRao
#plots RaoSummary and creates a list with the plots. Alternatively, it can save the plots.
plotsRao <- FD_plotRao(df = RaoSummary, save.plot=TRUE,ext=".png")

# Function 5 FD_plotPC
#plots the functional space, option to save
plotsFD <- FD_plotFS(df = FDSummary,plot.window=TRUE,save.plot= FALSE, ext=".png", add.labs = F)

#############
# Null models and plots

# Function 6 FD_nullcom
# Creates nNull null community from the original (data0) under a user-defined algorth "all", "col-wise" or "row-wise".
# Here u can setup if you want to run the function 7 and 8 immediately call.summary and plot.null, respectively.
FD_nullCom(df = data0, nNull = 3,call.nullsummary = T, plot.null = T, type="all")
# This function returs dataframes for Rao and FD statistics for each replicate/time bin


#Function 7 FD_nullSummary
# This function summarise the previous dataframes, calculating the mean, variance and CI.
FD_nullSummary(nullrao = null_rao, nullFD = null_FDmetrics, nNull = 3, plot.null = FALSE)

#Function 8 FD_plotNull
#This function plots the null estimate (mean +/- CI) and the observed trajectory
  FD_plotNull(d.rao = summarynullrao, d.FD = summarynullFD, plotRao = TRUE, saveRao = TRUE, plotFRic = TRUE, saveFRic = TRUE)

