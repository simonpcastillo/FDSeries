data0 <- as.data.frame(t(read.csv('/Users/scastillo/Dropbox (ICR)/FDSeries_Opazo_backup/FD Package_felipefx/EcoGenera.csv', sep=',', row.names = 1, check.names = F)))

datam<-FD_df(data0, subcat = c(6,6,6))
Fdstats<- FD_metrics(datam)


library(ggplot2)
library(patchwork)
library(zoo)
FDSummary <- Fdstats

head(FDSummary)
FDSummary$FRic<- as.numeric(as.character(FDSummary$FRic))
FDSummary$FSpe<- as.numeric(as.character(FDSummary$FSpe))
(ggplot(data = FDSummary, aes(x=as.numeric(as.character(time)), y = FRic)) +
    geom_point() +
    geom_line(aes(y=rollmean(FRic, 3, na.pad=TRUE))) +
    labs(x ="Time", y = "Functional richness") +
    scale_x_continuous(limits = c(-280, -160), breaks = seq(-280, -160, 20))+
    scale_color_viridis_d()+
    theme_bw()+
    theme(axis.text.x = element_text(angle=90)))/ggplot(data = FDSummary, aes(x=as.numeric(as.character(time)), y = FSpe)) +
  geom_point() +
  geom_line(aes(y=rollmean(FSpe, 3, na.pad=TRUE))) +
  labs(x ="Time", y = "Functional specialization") +
  scale_x_continuous(limits = c(-280, -160), breaks = seq(-280, -160, 20))+
  scale_color_viridis_d()+
  theme_bw()+
  theme(axis.text.x = element_text(angle=90))
